# The Ultimate Midterm Arena

Open `index.html` in any modern browser. No installation, build step, or network connection is required for the app itself.

## What is included

- Six independent lecture arenas with practice, timed exam, and study modes
- A persistent one-hour examination timer that survives refreshes and auto-submits at zero
- Question navigation, immediate practice feedback, detailed results, history, bookmarks, flashcards, keyboard shortcuts, and a reset control
- A configurable 40/50/60/80/100-question comprehensive-exam builder that prevents repeats within an attempt
- Light/dark mode and browser-local persistence

## Course-source question packs

The files supplied for this build did **not** include the lecture PDFs, PowerPoints, or previous professor exam. The built-in starter questions are intentionally marked as unverified and demonstrate functionality only.

To make the app academically ready, use **Question Library → Download JSON template**, fill it from the course materials, then choose **Import question pack**. Each entry needs:

```json
{
  "id": "L1-11",
  "lecture": 1,
  "topic": "Course topic",
  "question": "Question text?",
  "options": ["A", "B", "C", "D"],
  "answer": 0,
  "explanation": "Why the keyed answer is correct.",
  "difficulty": "medium",
  "source": "Lecture 1, slide 4",
  "tags": ["definition"]
}
```

`answer` is zero-based: `0` for A through `3` for D. Source packs are saved only in the current browser's local storage.
